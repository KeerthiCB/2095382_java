package com.cognizant.shapes;
import java.text.SimpleDateFormat;
//import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Example {
	public static void main(String args[])/*throws ParseException*/ { 
		Scanner sc=new Scanner(System.in);
		System.out.println("enter any date");
	String s1=sc.next();
		LocalDate todaysDate = LocalDate.now();
	       System.out.println("current date is "+todaysDate);
	       LocalDate entered_date = LocalDate.parse(s1);
	       System.out.println("entered date is "+entered_date);
	       if(todaysDate.compareTo(entered_date)==0){
	    	   System.out.println(todaysDate+" comes after "+entered_date);
	    	   
	       }
	       else
	    	   System.out.println("entered date comes after todays date");
	   
	      
	   }
}

