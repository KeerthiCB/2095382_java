package com.cognizant.shapes;

public class parentClass {
	int pAge=40;

	public void  hello(){
		System.out.println("parent class");
	}
}
