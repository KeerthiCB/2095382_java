package com.cognizant.shapes;

public class MainProg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		parentClass p=new parentClass();
		SonClass s=new SonClass();
		Daughter d=new Daughter();
		p.hello();
		System.out.println(p.pAge);
		s.hi();
		s.hi();
		d.daughter();
		System.out.println(s.pAge);
		System.out.println(s.sAge);


	}

}
