package com.cognizant.shapes;

import java.util.Scanner;

public class Circle extends Shape{
	public double calculateArea(){
		
		double area;
		double radius=5.0;
		area=3.14*radius*radius;
		System.out.println("Area of circle is: "+area);
		return area;
	}

}
