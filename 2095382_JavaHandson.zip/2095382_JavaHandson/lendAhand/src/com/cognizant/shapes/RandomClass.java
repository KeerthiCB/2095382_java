package com.cognizant.shapes;

import java.util.ArrayList;

public class RandomClass  {

	public static void main(String[] args)
	{
		//consoleApplication ca=new consoleApplication();
		//ArrayList aL=ca.getList();
		//System.out.println(aL);
		details d=new details();
		ArrayList a1=d.ar;
		System.out.println(a1);
	}

}
