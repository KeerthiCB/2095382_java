package com.cognizant.shapes;
import java.util.ArrayList;
import java.util.Scanner;
class consoleApplication {
	static ArrayList cus=new ArrayList(); 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int count=0;
		details d=new details();
		System.out.println("Select an option from below to perform particular operation");
		System.out.println("1. Register � registers a customer");
		System.out.println("2. Book � Book a room");
		System.out.println("3. Check Status � check for the rooms present status (Vacant / Booked)");
		System.out.println("4. Email � Change/ update an email address of the customer");
		System.out.println("5. All Bookings � Display all the bookings for a specific time period mentioned");
		System.out.println("6. All customers � Display all the registered customer details");
		System.out.println("enter any one option from 1-7");
		int n=sc.nextInt();
		switch(n){
		case 1 :cus=d.register();
		break;
		case 2: d.book();
		break;
		case 3: d.checkStatus();
		break;
		case 4: d.eMail();
		break;
		case 5: d.allBookings(cus);
		break;
		case 6: d.allCustomers();
		break;
		
		}
		System.out.println(cus);
		sc.close();
	}
	
public ArrayList getList(){
	return cus;
	
}

}
