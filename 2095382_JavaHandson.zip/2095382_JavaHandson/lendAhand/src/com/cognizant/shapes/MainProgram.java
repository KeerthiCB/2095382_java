package com.cognizant.shapes;

public class MainProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp=new Employee();
		System.out.println("The Id of Employee is "+emp.empId);
		System.out.println("The salary of Employee is "+emp.empSalary);
		System.out.println("The Percentage of Tax the Employee needs to pay is "+emp.empTax);
		System.out.println("The Total number of working days is "+emp.empDaysofWork);
		emp.calculatePF();

	}

}
