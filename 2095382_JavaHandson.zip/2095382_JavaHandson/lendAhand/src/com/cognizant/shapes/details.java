package com.cognizant.shapes;
import java.util.*;

public class details {
	ArrayList<Comparable> ar=new ArrayList();
	String name;
	int id;
	long contactNo;
	ArrayList register()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name, id, contactNo");
		 name=sc.nextLine();
		id=sc.nextInt();
		contactNo=sc.nextLong();
		ar.add(name);
		ar.add(id);
		ar.add(contactNo);
		//System.out.println(name);
		//System.out.println(id);
		//System.out.println(contactNo);
		
		return ar;
	
	}
	void book()
	{
		Scanner sc=new Scanner(System.in);
		String s1="AC";
		String s2="Non-AC";
		System.out.println("AC or Non-AC room?");
		String s3=sc.nextLine();
		if(s1.equals(s3))
			System.out.println("Charges for AC room is Rs-1000/");
		
		else
			System.out.println("Charges for Non-AC room is Rs-700/");
			
	}
	void checkStatus()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter age");
		int age=sc.nextInt();
		if(age>=21)
			System.out.println("customer is an employee");
		else
			System.out.println("customer is a student");
		
	}
	void eMail()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter emailId");
		String mail=sc.next();
		if(mail.contains("cognizant")){
			System.out.println("customer is cognizant employee");
		}
		else
			System.out.println("customer is a guest");
	}
	void allBookings(ArrayList c)
	{
		
	}
	void allCustomers()
	{
		
	}
	
	

}
