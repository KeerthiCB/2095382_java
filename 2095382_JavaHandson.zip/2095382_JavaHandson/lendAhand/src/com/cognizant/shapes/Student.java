package practice;

public class Student {
	static int registrationId;
 static void displayRegistrationId(){
	System.out.println("The Student registration id is "+registrationId);
}
}
