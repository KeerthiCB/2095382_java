package com.cognizant.shapes;

public class SonClass extends parentClass{
	int sAge=20;
	public void hi(){
		System.out.println("son class");
	}

}
