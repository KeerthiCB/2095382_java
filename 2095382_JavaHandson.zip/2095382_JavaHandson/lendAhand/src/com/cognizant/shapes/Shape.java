package com.cognizant.shapes;

abstract public class Shape {
	String color;
	abstract public double calculateArea();
	public void setColor(String color){
		this.color=color;
		System.out.println("The color is "+this.color);
	}

}
