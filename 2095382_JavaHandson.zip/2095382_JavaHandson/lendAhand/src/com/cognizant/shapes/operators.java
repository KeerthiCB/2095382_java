package com.cognizant.shapes;

public class operators {
	int num1,num2;
	void and()
	{
		System.out.println("The bitwise and of two numbers "+num1+" and "+num2+" is "+(num1&num2));
	}
	void or()
	{
		System.out.println("The bitwise or of two numbers "+num1+" and "+num2+" is "+(num1|num2));
	}
	void xor()
	{
		System.out.println("The bitwise xor of two numbers "+num1+" and "+num2+" is "+(num1^num2));
	}
	void not()
	{
		System.out.println("The bitwise not of two numbers "+num1+" is "+(~num1));
	}

}
