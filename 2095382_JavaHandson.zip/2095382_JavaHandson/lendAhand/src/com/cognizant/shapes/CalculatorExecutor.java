package practice;

public class CalculatorExecutor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculator c=new Calculator();
		c.operand1=89;
		c.operand2=34;
		c.displayOperand();

	}

}
