package com.cognizant.shapes;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		calculator c=new calculator();
		c.num1=12;
		c.num2=8;
		c.addition();
		c.subtraction();
		c.printSmaller();

	}

}
