package com.cognizant.shapes;

public class Daughter extends parentClass{
	int dAge=22;
	public void daughter(){
		System.out.println("daughter class");
	}

}
