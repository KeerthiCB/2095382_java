package com.cognizant.shapes;

public class MainOp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		operators op=new operators();
		op.num1=15;
		op.num2=5;
		op.and();
		op.or();
		op.xor();
		op.not();

	}

}
