package com.cognizant.shapes;

public class Square extends Shape
{
	public double calculateArea(){
		double length=4.0;
		double breadth=4.0;
		double area=length*breadth;
		System.out.println("Area of Square is: "+area);
		return area;
	}
	

}
