package practice;

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student stu=new Student();
		stu.registrationId=1290;
		stu.displayRegistrationId();

	}

}
