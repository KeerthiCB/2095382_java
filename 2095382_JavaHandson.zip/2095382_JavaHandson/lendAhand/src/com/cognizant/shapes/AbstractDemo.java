package com.cognizant.shapes;

public class AbstractDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle c=new Circle();
		Square s=new Square();
		c.setColor("Sky-Blue");
		s.setColor("Green");
		c.calculateArea();
		s.calculateArea();
		
		
	}

}
