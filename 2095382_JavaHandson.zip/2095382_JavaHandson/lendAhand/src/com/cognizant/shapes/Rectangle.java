package com.cognizant.shapes;

public class Rectangle {
	int length,breadth;
	void calculateArea(){
		System.out.println("the area of rectangle is "+(length*breadth));
	}

}
