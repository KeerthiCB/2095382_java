package com.cognizant.shapes;

public class AreaCalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle r=new Rectangle();
		r.length=10;
		r.breadth=20;
		r.calculateArea();

	}

}
