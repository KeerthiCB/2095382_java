package com.cognizant.shapes;

public interface IVehicle {

}
