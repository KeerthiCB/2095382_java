package practice;
import java.util.Scanner;
public class employee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter string");
		String s1=sc.nextLine();
		System.out.println(s1);
		System.out.println("Hello");

	}

}
