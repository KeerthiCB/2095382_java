package byCycle;

public class SeniorCitizen extends BankAccount{
	public void applyFixeddeposit(){
		interestRate=10.5f;
		System.out.println("Interest rate is "+interestRate);
		
	}

}
