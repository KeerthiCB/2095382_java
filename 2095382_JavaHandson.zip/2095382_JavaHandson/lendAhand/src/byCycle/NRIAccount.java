package byCycle;

public class NRIAccount extends BankAccount {
	public void applyFixeddeposit(){
		interestRate=6.5f;
		System.out.println("Interest rate is "+interestRate);
		
	}

}
