package byCycle;

public class RunTimePolymorphismDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal a=new Animal();
		Dog d=new Dog();
		Cow c=new Cow();
		Snake s=new Snake();
		a.whoAmI();
		d.whoAmI();
		c.whoAmI();
		s.whoAmI();

	}

}
