package byCycle;

public class BankAccount {
	long depositAmount=5000;
	long withdrawAmount=1000;
	long balance;
	float interestRate=9.5f;
	public void depositMoney(){
		System.out.println("Deposited money is "+depositAmount);
	}
	public void withdrawMoney(){
		System.out.println("withdrawl money is "+withdrawAmount);
		balance=depositAmount-withdrawAmount;
		System.out.println("Balance is "+balance);
	}
	public void applyFixedDeposit(){
		interestRate=8;
		System.out.println("deposit amount for a normal bank is :");
	}
}
