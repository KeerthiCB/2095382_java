package byCycle;

public class InheritanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NRIAccount n=new NRIAccount();
		SeniorCitizen s=new SeniorCitizen();
		n.depositMoney();
		n.withdrawMoney();
		s.depositMoney();
		s.withdrawMoney();
		n.applyFixeddeposit();
		s.applyFixeddeposit();
	}

}
