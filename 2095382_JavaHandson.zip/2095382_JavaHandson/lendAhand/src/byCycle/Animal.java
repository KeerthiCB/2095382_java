package byCycle;

public class Animal {
	public void whoAmI(){
		System.out.println("I am an Animal");
	}

}
