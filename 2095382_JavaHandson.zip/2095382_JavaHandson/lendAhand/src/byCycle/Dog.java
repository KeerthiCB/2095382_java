package byCycle;

public class Dog extends Animal {
	public void whoAmI(){
		System.out.println("I am a Dog");
	}

}
