package byCycle;

public class Cow extends Animal {
	public void whoAmI(){
		System.out.println("I am a Cow");
	}

}
