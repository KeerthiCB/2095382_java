package byCycle;

public class Snake extends Animal {
	public void whoAmI(){
		System.out.println("I am a Snake");
	}

}
