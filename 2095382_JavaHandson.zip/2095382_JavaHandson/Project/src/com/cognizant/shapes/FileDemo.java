package com.cognizant.shapes;
import java.io.File;
import java.io.IOException;
import java.util.Date;
public class FileDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File f = new File("C:\\Users\\2095382\\workspace\\EmployeeMain.java");
		File f1 = new File("C:\\Users\\2095382");
		System.out.println(f.getName());
		System.out.println(f.length());
		System.out.println(f.canRead());
		System.out.println(f.canWrite());
		System.out.println(f.isFile());
		System.out.println(f.isDirectory());
		System.out.println(f.isHidden());
		System.out.println(f.lastModified());
		System.out.println(new Date(f.lastModified()));
		
		String fname[] = f1.list();
		
		for(String p:fname) {
			System.out.println(p);
		}
		
		
		System.out.println("List of Files Using listFiless()...");
		File fna[]= f1.listFiles();
		
		for(File ff : fna) {
			System.out.println(ff.getPath());
		}
		
		File c =  new File("C:\\Users//io.txt");
		c.createNewFile();
		//C:\Users\2095382\workspace

	}

}
