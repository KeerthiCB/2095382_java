package com.cognizant.shapes;

public abstract class University {
	public abstract void basicFees();
	public void uniCourses() {
		System.out.println("ECE");
		System.out.println("EEE");
		System.out.println("ME");
	}

}
