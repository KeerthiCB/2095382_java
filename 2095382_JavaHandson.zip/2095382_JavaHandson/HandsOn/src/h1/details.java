package h1;
import java.util.*;

public class details {
	ArrayList<Comparable> ar=new ArrayList();
	String name;
	int id;
	long contactNo;
	int age;
	String mail;
	static int maxroom = 100;
	static int regcount = 0;
	static int roomcount = 0;
	ArrayList register()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name, id, contactNo");
		 name=sc.nextLine();
		id=sc.nextInt();
		contactNo=sc.nextLong();
		ar.add(name);
		ar.add(id);
		ar.add(contactNo);
		//System.out.println(name);
		//System.out.println(id);
		//System.out.println(contactNo);
		
		
		return ar;
	
	}
	void book()
	{
		Scanner sc=new Scanner(System.in);
		String s1="AC";
		String s2="Non-AC";
		System.out.println("AC or Non-AC room?");
		String s3=sc.nextLine();
		if(s1.equals(s3))
			System.out.println("Charges for AC room is Rs-1000/");
		
		else
			System.out.println("Charges for Non-AC room is Rs-700/");
			
	}
	void checkStatus()
	{
		Scanner sc=new Scanner(System.in);
		/*System.out.println("enter age");
		age=sc.nextInt();
		ar.add(age);
		if(age>=21)
			System.out.println("customer is an employee");
		else
			System.out.println("customer is a student"); */
		System.out.println("Please select an option");
		System.out.println("0. Continue checking the room details");
		System.out.println("1. Menu");
		int y = sc.nextInt();
		if(y == 0)
		{
			for(int i=1;i<=roomcount;i++)
			{
				System.out.println("Room number " + i + " Occupied");
			}
			System.out.println("Vacant rooms count : " + (maxroom-roomcount));
			quit();
		}
		
	}
	void eMail()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter emailId");
	     mail=sc.next();
	     ar.add(mail);
		if(mail.contains("cognizant")){
			System.out.println("customer is cognizant employee");
		}
		else
			System.out.println("customer is a guest");
	}
	ArrayList allBookings()
	{
		return ar;
	}
	void quit()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Thank you");
		sc.nextLine();
	}
	
	

}
