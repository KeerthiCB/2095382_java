package h1;
import java.util.*;
public class Reservation {
	ArrayList al=new ArrayList();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the details for registration");
		System.out.println("Enter the Name of the guest");
		String name=sc.next();
		
		

	}

}
